/bin/bash: q: command not found
	<head>
		<title>Detail of the Recipe</title>
	</head>

	<body>
		<?php
			//defines the variable dishid as the global variable that is taken from the url
			//this variable was passed from the search page as the filled in recipe_id in the url
		    $dishid=$_GET['dishid'];

		    //defines the 4 variables needed to create a database link
			$host = "localhost";
			$user = "foodieleague";
			$password = "inf385";
			$database = "foodieleague";

			//creates a link to the MySQL database through the mysqli_connect command
		    //mysqli_connect command needs the four inputs of the host, username, password, and database name
			$link = mysqli_connect($host, $user, $password, $database); 

			$searchq = "SELECT recipe_name, image, description, direction FROM recipe WHERE recipe_id = $dishid";

			//creates the query and link relationship that will be passed through
			$listresult = mysqli_query($link, $searchq);
			//creates the variable row and assigns it to the array formed from the MySQL query
			$result = mysqli_fetch_array($listresult);

			//Creates the relationship between the recipe, recipe_ingredient, and ingredient tables by linking id numbers
			$searchq2="SELECT recipe_name, in_name 
				  FROM recipe, recipe_ingredient, ingredient 
				  WHERE recipe.recipe_id = $dishid
				  AND recipe.recipe_id = recipe_ingredient.recipe_id
				  AND ingredient.in_id = recipe_ingredient.in_id";
			$listresult2 = mysqli_query($link, $searchq2);

			//print the data.
			print "<h1>$result[recipe_name]</h1><br/>";
			print "<image width='375' height='300' src=\"../pictures/$result[image]\"><br/><br/>";
			print "Description: $result[description]<br/><br/>";
			print "Ingredients:<br/><br/>";
			while($row = mysqli_fetch_array($listresult2)){
				print "$row[in_name]";
			}
                        print "<br/><br/>";			 
                      print "Direction: $result[direction]<br/><br/>";

			mysqli_close($link);
		?>

		<a href="homepage.php"><input type="button" value="Go Back to the homepage"></input></a>
	             
	        </body>
</html>
