<html>
    <head>
        <title> A simple search form </title>
    </head>

    <body>
        <h1>Come here to learn Cooking!!!</h1>

        <form method = "GET" action="homepage.php"><br/>Select the filter of the searching<br />

            <select name="keyword"><br/>
                <option ></option>
                <option >type(soup/dish/staple food)</option>
                <option >district</option>
                <option >cuisine</option>
                <option >ingredient</option>
                <option >recipe name</option>
            </select><br/>

            </p>Input your keywords to search for the results！</p>
            <input type="text" size="40" name="search">
            <input type="submit" value="Submit">   

        </form>

        <div style="width: 1200px; height: 1500px;">         
            <?php                                                  //defines the 4 variables needed to create a database link

                $host= "localhost";
                $user= "foodieleague";
                $password= "inf385";
                $database="foodieleague";

                $link = mysqli_connect($host, $user, $password,$database);        //creates a link to the MySQL database through the mysqli_connect command

                if ($_GET['search']=='' && $_GET['keyword']==''){                  //set an if isset loop to check if search box and keyword box are empty
                    $searchqa = "SELECT *  FROM recipe  GROUP BY recipe_name";
                    $listresulta=mysqli_query($link,$searchqa);
               
                    while($row = mysqli_fetch_array($listresulta)){                     // print all recipe
                        print "<div style=\"width:250px; height:200px;float:left;margin-top:50px;margin-right:25px;margin-left:25px;margin-bottom:50px;\">";
                        print "<image src=\"../pictures/$row[image]\" height=\"200px\" width=\"250px\"><br />";
                        print "<a href='detail.php?dishid=$row[recipe_id]' style=\"text-align:center;display:block;\">$row[recipe_name]</a>";
                        print "</div>";
                    }                    
                 }

                if( isset($_GET['search'])){         //set an if isset loop to check if search box and keyword box are entered           
                    $search = $_GET['search'];
                    $keyword = $_GET['keyword'];
                    $search = preg_replace("/[^ 0-9a-zA-Z]+/","",$search);

                    if($keyword=='type(soup/dish/staple food)'){     // different keywords match different SELECT statements                
                        $searchq = "SELECT * FROM recipe,type WHERE type.type_name='$search' AND type.type_id=recipe.type_id GROUP BY recipe_name";
                    } 

                    if($keyword == 'cuisine') {
                        $searchq = "SELECT * FROM recipe,cuisine WHERE cuisine.cu_name LIKE '%$search%' AND cuisine.cu_id=recipe.cuisines_id GROUP BY recipe_name";
                    }
                                       
                    if($keyword=='district'){
                        $searchq = "SELECT *  FROM recipe,district WHERE district.di_name LIKE '%$search%' AND district.di_id=recipe.district_id GROUP BY recipe_name";
                    }

                    if($keyword=='ingredient'){
                        $searchq = "SELECT *  FROM recipe,ingredient,recipe_ingredient WHERE ingredient.in_name LIKE '%$search%' 
                                            AND ingredient.in_id=recipe_ingredient.in_id 
                                            AND recipe_ingredient.recipe_id=recipe.recipe_id
                                            GROUP BY recipe_name";
                    } 
                  
                    if($keyword=='recipe name'){
                        $searchq = "SELECT *  FROM recipe WHERE recipe_name LIKE'%$search%'
                                            
                                            GROUP BY recipe_name";
                    }

                    $listresult=mysqli_query($link,$searchq);     
                    print "<p>Here are the recipes that match your search:</p>";  //print all recipes that match search requirments;
                    while($row = mysqli_fetch_array($listresult)){
                        print "<div style=\"width:250px; height:200px;float:left;margin-top:50px;margin-right:25px;margin-left:25px;margin-bottom:50px;\">";
                        print "<image src=\"../pictures/$row[image]\" height=\"200px\" width=\"250px\"><br />";
                        print "<a href='detail.php?dishid=$row[recipe_id]' style=\"text-align:center;display:block;\">$row[recipe_name]</a>";
                        print "</div>";
                    }
                  


                mysqli_close ($link);
                }
          
            ?>
        </div>

     </body>
</html>
